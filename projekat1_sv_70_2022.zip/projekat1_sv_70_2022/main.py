import game

print("Welcome to Reversi! \n")

new_game = game.Game()
new_game.game_start()
